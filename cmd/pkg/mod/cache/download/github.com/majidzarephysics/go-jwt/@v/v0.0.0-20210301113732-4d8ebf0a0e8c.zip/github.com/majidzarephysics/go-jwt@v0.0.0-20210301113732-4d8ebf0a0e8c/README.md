# go-jwt
Simple jwt authentication in golang with gin as web framework
